# Trabalho 3 de Programação -- Programação Dinâmica
### IFES - Análise e Complexidade de Algoritmos  

**Autor:** Adriel Monti De Nardi
**Matrícula:** 20202mpca0014
**Data:** 23 de maio de 2021 
**Problema:** 01213 – Sum of Different Primes
**Professor:** Prof. Dr. Jefferson O. Andrade


## Sobre o Diretório 

Este diretório contém este documento Markdown, o código fonte para solucionar o problema 01213, e o print com a aprovação do *Online Judge* e *Udebug*. 


O problema recebeu aprovação pelo site Online Judge como mostrado na figura abaixo:

![Veredito](./01213-veredito.png)

Também foi validado no site Udebug, como mostrado abaixo:

![Veredito](./01213-udebug.png)


## Código Fonte e sua complexidade

O programa foi desenvolvido em PYTH3.

Para solução do problema segue abaixo o código fonte e em seguida a sua complexidade:

```
import fileinput

lista = []
primos = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107,
          109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229,
          233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359,
          367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491,
          499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641,
          643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787,
          797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941,
          947, 953, 967, 971, 977, 983, 991, 997, 1009, 1013, 1019, 1021, 1031, 1033, 1039, 1049, 1051, 1061, 1063, 1069,
          1087, 1091, 1093, 1097, 1103, 1109, 1117, 1123, 1129, 1151, 1153, 1163, 1171, 1181, 1187, 1193, 1201, ]

def result(n,k,i):
    if n > 0 and k == 0:
        return 0
    if k == 0 and n == 0:
        return 1
    if n < 0 or k < 0:
        return 0
    if primos[i] > n:
        return 0
    if m[n][k][i] != -1:
        return m[n][k][i]

    m[n][k][i] = result(n - primos[i], k-1, i+1) + result(n, k, i+1)
    return m[n][k][i]


if __name__ == "__main__":
    while True:
        try:
            #carrega a matriz[i][j][k] recebendo valor -1
            m = [[[-1 for k in range(200)] for j in range(15)] for i in range(1121)]

            for t in fileinput.input():

                #pega os valores n e k do input
                linha = t.split()
                n = int(linha[0])
                k = int(linha[1])
                # aux recebe o valor da função recursiva
                aux = result(n,k,0)
                lista.append(aux)

        except EOFError:
            break
        finally:
            #lista recebe valores de 0 até o penúltimo elemento
            # obs: último elemento n=0, k=0 recebe 1 no código por isso ele é descartado
            lista = lista[0:-1]
            #resultado do output
            for i in lista:
                print(i)
            exit(0)

```

Função Principal:

Função def main():

Função def trib():



## Sobre a Solução 

**Programação Dinâmica**
-Busca encontrar a solução de vários subproblemas, para então, encontrar a solução do problema geral.
-Usada em casos de otimização combinatória.
-Solução ótima calculada e memorizada para evitar recalculo para problemas de otimização.

**Problema**

Temos dois inteiros n e k, n é o valor máximo da soma dos números primos  e k é a quantidade de elementos inteiros que vai envolver essa soma. Para resolver está questão usamos uma função recursiva de divisão e conquista.

**Etapas:**	

1 - O programa começa carregando uma matriz onde temos uma lista de 1121 itens (valor máximo de n 1120), cada item dessa lista tem 15 itens (valor máximo de k é 14), e por fim dentro de cada item temos uma listagem de 200 itens , toda posição ijk da matriz recebe valor -1.

2 - A cada linha do input vai receber os valores n e k, até encerrar o programa ("0 0").

3 - Recebendo os valores de n e k, a váriável aux recebe o valor inteiro da função def result() que recebe os parâmetros, os valores n, k e um contador inicialmente na posição 0

4 - Inicialmente na função def result() temos a seguinte seguencia de condições:

Se n > 0 **e** k == 0, retorne 0

Se k == 0 **e** n == 0, retorne 1

Se n < 0 **ou** k < 0, retorne 0

Se o primo[i do parâmetro] != -1, ou seja, se não tiver -1 é porque ja esta calculado o seu valor, então retorna: 

```
  if m[n][k][i] != -1:
        return m[n][k][i]
```

Se não for o caso, então fora das condições, o calculo recursivo será feito através do seguinte código

```
m[n][k][i] = result(n - primos[i], k-1, i+1) + result(n, k, i+1)
return m[n][k][i]
```

**A matriz  atual dividi o problema original em subproblemas menores da mesma natureza, e depois combina estas soluções obtidas para gerar a solução do problema original de tamanho maior, entre estas divisões se k == 0 e n == 0 , ele vai retornar 1.**

**Entre todos os problemas divididos, os que satisfazer a soma total n de k numeros de elementos diferentes, o valor total vai ser gerado o output do problema.**

5 - Cada resposta output é adicionado a uma lista, que será depois mostrada na tela.




## Outras Informações

**Premissas:**

$$
n ≤ 1120
$$

$$
k ≤ 14
$$

**Input:**

24 3
24 2
2 1
0 0

**Output:**

2 ->  {2, 3, 19} e {2, 5, 17}
3 ->  {5, 19}, {7, 17} e {11, 13}
1 -> {2}