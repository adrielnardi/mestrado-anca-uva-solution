# Trabalho 3 de Programação -- Programação Dinâmica
### IFES - Análise e Complexidade de Algoritmos  

**Autor:** Adriel Monti De Nardi
**Matrícula:** 20202mpca0014
**Data:** 12 de maio de 2021 
**Problema:** 10446 – The Marriage Interview :-)
**Professor:** Prof. Dr. Jefferson O. Andrade


## Sobre o Diretório 

Este diretório contém este documento Markdown, o código fonte para solucionar o problema 10446,
e o print com a aprovação do *Online Judge* e *Udebug*. 


O problema recebeu aprovação pelo site Online Judge como mostrado na figura abaixo:

![Veredito](./10446-veredito.png)

Também foi validado no site Udebug, como mostrado abaixo:

![Veredito](./10446-udebug.png)


## Código Fonte e sua complexidade

O programa foi desenvolvido em PYTH3.

Para solução do problema segue abaixo o código fonte e em seguida a sua complexidade:

```
import fileinput

def trib(n,back):
    # se n<1 recebe 1
    # se senão:
    #   matriz[n][back] for diferente de 0
    #   retorna o valor armazenado nesta matriz
    if n <=1:
        return 1
    elif x[n][back] != 0:
        return x[n][back]

    #se a matriz atual for 0, começa recebendo valor 1
    x[n][back] = 1
    # adiciona no valor atual da matriz a quantidade de
    # chamadas da função recursiva
    for i in range(1,back+1):
        x[n][back] = x[n][back] + trib(n-i,back)
    return x[n][back]


def main():
    caso = 1 #contador de casos
    #le linha a linha do input
    for l in fileinput.input():
        #encerra o programa no final da linha
        if l == "\n":
            break
        #recebe os valores n e back para cada caso teste
        linha = l.split()
        n = int(linha[0])
        back = int(linha[1])
        #verifica antes se n > 60
        if n > 60:
            break
        # chama função trib(n,back)
        print(f"Case {caso}: {trib(n,back)}")
        caso = caso+1


if __name__ == "__main__":
    while True:
        try:
            #carrega a matriz com valor 0 em cada i,j da matriz
            x = [[0 for y in range(61)] for x in range(61)]
            #entra na função def main()
            main()
        except EOFError:
            break
        finally:
            exit(0)




```

Função Principal:

Função def main():

Função def trib():



## Sobre a Solução 

**Programação Dinâmica**
-Busca encontrar a solução de vários subproblemas, para então, encontrar a solução do problema geral.
-Usada em casos de otimização combinatória.
-Solução ótima calculada e memorizada para evitar recalculo para problemas de otimização.

**Problema**

Esta solução do problema visa contar quantas vezes é chamada a função trib(), o número de vezes que essa função é chamada de acordo com as variáveis de input n e back. Para isso, é utilizado um método de recursividade, e cada função trib(n,back) é somado quantas vezes é chamada e adicionado na posição da matriz

**Etapas:**	

1 - Quando o programa é iniciado ele carrega uma matriz de 61 linhas e 61 colunas recebendo valor 0, logo em seguida entra na função main().

2 - na função main() começa a leitura dos inputs, linha a linha, recebendo os valores das posições das variáveis *n* e *back*, satisfazendo a premissa de n ser menor que 60, entramos na função trib(n,back)

3 - A função trib(n,back) temos:

```
def trib(n,back):
    if n <=1:
        return 1
    elif x[n][back] != 0:
        return x[n][back]
    x[n][back] = 1

    for i in range(1,back+1):
        x[n][back] = x[n][back] + trib(n-i,back)
    return x[n][back]
```

No laço é usado uma recursividade que vai decrementando, até chegar a n<=1 , e todo esse valor das recursivades são somados, retornando o número de vezes que a função trib() é chamada,

4 - A entrada é encerrada por um caso em que n > 60, está linha não será processada, as demais, produzira uma linha de saída que vai conter o número de casos através de uma variável chamado *caso*




## Outras Informações

**Premissas:**
$$
n ≤ 61
$$

$$
back ≤ 60
$$

**Input:**

3 3
4 4
5 5

**Output:**

Case 1: 7
Case 2: 17
Case 3: 41


