

### IFES - Análise e Complexidade de Algoritmos  

**Autor:** Adriel Monti De Nardi
**Matrícula:** 20202mpca0014
**Data:** 14 de maio de 2021 
**Problema:** 10520 – Determine It
**Professor:** Prof. Dr. Jefferson O. Andrade


## Sobre o Diretório 

Este diretório contém este documento Markdown, o código fonte para solucionar o problema 10520,
e o print com a aprovação do *Online Judge* e *Udebug*. 

O problema recebeu tempo limite excedido "Time limit exceeded", pelo Online Judge como mostrado na figura abaixo:

![Veredito](./10520-veredito.png)

Entretanto, o programa recebeu toda a aprovação em um tempo hábil no Udebug, conforme a figura abaixo:

![Veredito](./10520-udebug.png)


## Código Fonte e sua complexidade

O programa foi desenvolvido em PYTH3.

Para solução do problema segue abaixo o código fonte e em seguida a sua complexidade:

```

import fileinput
r = 0

def aij(n, i, j):
    r = a[i][j]
    if r != -1:
        return r
    if i < j:
        k = i
        while k < j:
            r = max(r, aij(n, i, k) + aij(n, k + 1, j))
            k = k + 1
    else:
        r0,r1=0,0
        if i < n:
            k = i + 1
            while k <= n:
                r0 = max(r0, aij(n, k, 1) + aij(n, k, j))
                k = k + 1
        if j > 0:
            k = 1
            while k < j:
                r1 = max(r1, aij(n, i, k) + aij(n, n, k));
                k = k + 1
        r = r0 + r1
    a[i][j] = r
    return a[i][j]



def main():

    for l in fileinput.input():
        if l == "\n":
            break

        linha = l.split()
        n = int(linha[0])

        for i in range(n+1):
            for j in range(n+1):
                a[i][j] = -1

        an1 = int(linha[1])

        a[n][1] = an1
        print(aij(n, 1, n))


if __name__ == "__main__":
    while True:
        try:
            #carrega a matriz com valor 0 em cada i,j da matriz
            a = [[0 for y in range(21)] for x in range(21)]
            #entra na função def main()
            main()

        except EOFError:
            break
        finally:
            exit(0)




```

Função Principal:

Função def main():

Função def trib():



## Sobre a Solução 

**Programação Dinâmica**
-Busca encontrar a solução de vários subproblemas, para então, encontrar a solução do problema geral.
-Usada em casos de otimização combinatória.
-Solução ótima calculada e memorizada para evitar recalculo para problemas de otimização.

**Problema**

No problema 10520 com base nos valores n e an,1 deve se calcular o valor a1,n. Para resolver está solução utilizamos programação dinâmica com uma função de chamada recursiva.

Segue abaixo o valor a1,n :
$$
a_{i,j} = [max_i<k≤n(a_{k,1} + a_{k,j}), i < n ];[0, i = n] + [max_1≤k≤j(a_{i,k} + a_{n,k}), j > 0 ];[0, j = 0] , i ≥ j
$$

$$
a_{i,j} = [max_i≤k <j(a_{i,k}+a_{k+1,j})], i < j
$$

**Etapas:**	

1 - O programa começa carregando uma matriz com 21 linhas e 21 colunas, cada valor ai,j da matriz recebe valor 0, em seguida entra na função def main().

2 - Na função def main() recebe linha a linha do input, atribuindo os valores n e an1, além disso tem um Laço que pecorre n linhas e n colunas, mudando valor 0 para -1 conforme o tamanho de n. Logo apos, entra na função def aij() em que vai gerar o resultado a1,n.

3 -  Na função def aij() temos:

Se i < j , k recebe i e enquanto o k < j ele recebe um contador, e é calculado o max  através de uma chamada recursiva, conforme mostrado abaixo:

```
r = max(r, aij(n, i, k) + aij(n, k + 1, j))
```

4 -  Na função def aij() temos:

Se  i < n , k recebe i + 1, enquanto o k <=n ele recebe  um contador, e é calculado o max de r0 através de uma chamada recursiva, conforme é mostrado abaixo.

```
r0 = max(r0, aij(n, k, 1) + aij(n, k, j))
```

Se j > 0  então k vai receber 1 e enquanto k < j , ele recebe um contador, e é calculado o max de r1 através de uma chamada recursiva, conforme é mostrado abaixo

```
r1 = max(r1, aij(n, i, k) + aij(n, n, k));
```

A resposta de r é calculada somando r0 e r1:

```
r = r0 + r1
```

5 - ao obter a resposta de r, ele retorna na sua posição aij-




## Outras Informações

**Função:**
$$
a_{i,j} = [max_i<k≤n(a_{k,1} + a_{k,j}), i < n ];[0, i = n] + [max_1≤k<j(a_{i,k} + a_{n,k}), j > 0 ];[0, j = 0] , i ≥ j
$$

$$
a_{i,j} = [max_i≤k <j(a_{i,k}+a_{k+1,j})], i < j
$$

**Premissas:** 
$$
0 < n < 20
$$

$$
0 <a_{n, 1} < 500
$$

**Input:**

5 10
4 1
6 13

**Output:**

1140
42
3770


